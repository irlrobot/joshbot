module.exports = [
  "Rindfleischetikettierungsüberwachungsaufgabenübertragungsgesetz",
  "Ihre Mutter säugt Schweine"
];
