module.exports = [
  "If you can't stand the heat, get out of the kitchen.",
  "Let's go watch a baseball game on Sunday."
];
