module.exports = [
  "Cheers for getting me that drink mate!",
  "You need to wear a coat today, it’s brass monkeys outside."
];
